public class StringBuilderDemo {
    public static void main(String[] args) {

       // StringBuilder sb = new StringBuilder("sadeep");
        //append method
//        int[] arr={1,2,3,4,5};
//        sb.append(Arrays.toString(arr)).append(123).append("sandeep").append(true);
//        System.out.println(sb);

        //insert method

//        StringBuilder sb = new StringBuilder("sadeep");
//        sb.insert(2,'n');
//        char[] charArr={'h','e','l','l','o'};
//        sb.insert(0,charArr,0,4);
//        System.out.println(sb);
        // capacity method
        
    }
}
