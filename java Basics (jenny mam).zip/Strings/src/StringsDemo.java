public class StringsDemo {
    public static void main(String[] args) {
        String str1="sandeep";
        String str2="sandeep";
        String str3 = new String("sandeep");
        System.out.println(str1==str2);
        System.out.println(str1==str3);
    }
}
