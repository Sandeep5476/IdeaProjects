public class Ex2 {
    public static void main(String[] args) {
        int sum=0,i=0;
        while(i<=10){
            sum += i;
            i++;
        }
        System.out.println(sum);
    }
}
