// we use continue only for loops not for switch
public class Continue {
    public static void main(String[] args) {
        for(int i = 0 ;i<5;i++){
            if(i == 2){
                continue;
            }
            System.out.println("Current value: "+i);
        }
    }
}
