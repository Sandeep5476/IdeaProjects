public class LabeledContinue {
    public static void main(String[] args) {
        outerLoop: for(int i = 0;i < 3;i++){
            for(int j=0;j<3;j++){
                if(i == 1 && j == 1){
                    System.out.println("Breaking both loops");
                    continue outerLoop;
                }
                System.out.println("i= "+i+" "+" j = "+j);
            }
        }
    }
}
