public class Greet {
    static void greet(String name,String timeOfDay){
        System.out.println("Hello "+name+" Good "+timeOfDay);
    }

    public static void main(String[] args) {
        greet("Sandeep","AfterNoon");
    }
}
