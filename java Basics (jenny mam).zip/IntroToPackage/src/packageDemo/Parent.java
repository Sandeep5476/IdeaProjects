package packageDemo;

public class Parent {
    public int publicVar=10;
    private int privateVar=20;
    protected int protectVar=30;
    int defaultVar=40;

}
