package ConstructorInheritance;

public class Main {
    public static void main(String[] args) {
     Employee obj = new Employee("sandeep","333","ramireddy nagar");
        System.out.println(obj.toString());
    }
}
