package ConstructorCodingExercises;

public class BookMain {
    public static void main(String[] args) {
//      Book obj = new Book();
//      obj.displayDetails();
        Book obj = new Book("Mastering java","jenny");
        obj.displayDetails();
    }
}
