package ConstructorCodingExercises;

public class ProductMain {
    public static void main(String[] args) {
        Product obj = new Product("Laptop","dell123");
        obj.displayDetails();
    }
}
