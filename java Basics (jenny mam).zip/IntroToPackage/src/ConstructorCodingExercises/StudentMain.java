package ConstructorCodingExercises;

public class StudentMain {
    public static void main(String[] args) {
        Student obj = new Student("Sandeep","23bq1a5476",(short)76);
        obj.setName("sandeep korrapati");
        System.out.println("Name: "+obj.getName());

    }
}
