package MyPackage1;

public class ConstructorIntroMain {
    public static void main(String[] args) {

        ConstructorIntro defaultConstructor = new ConstructorIntro();
        defaultConstructor.displayDetails();
        System.out.println();
//        ConstructorIntro fourParametrizedConstructor = new ConstructorIntro("123accnum","Korrapati sandeep",123456,1234567890);
//        fourParametrizedConstructor.displayDetails();
//        System.out.println();
//        ConstructorIntro threeParametrized = new ConstructorIntro("123accnum","sandeep Korrapati",123456);
//        threeParametrized.displayDetails();
    }
}
