package MyPackage1;

public class CircleMain {
    public static void main(String[] args) {
     Circle circle1 = new Circle();
     circle1.setRadius(-2.3);
     System.out.println("The area is: "+circle1.getArea());
        System.out.println("The circumference is: "+circle1.getCircumference());
    }
}
