package MyPackage1;

public class RectangleTestDrive {
    public static void main(String[] args) {
     Rectangle obj1 = new Rectangle();
      obj1.setLength(3).display();


//      obj1.setBreadth(5);
//      obj1.display();

    }
}
