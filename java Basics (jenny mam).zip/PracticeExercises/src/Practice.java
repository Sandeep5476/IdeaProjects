public class Practice {
    public static void main(String[] args) {
        int a = 12323;
        int b = a/10;
        System.out.println(b);
    }
}
