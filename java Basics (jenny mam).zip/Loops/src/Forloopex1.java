public class Forloopex1 {
    public static void main(String[] args) {
        int i=1,j=20;
        for(i=2,j=10;i<=j;i++,j--);
        {
            System.out.println(i);
        }
    }
}
