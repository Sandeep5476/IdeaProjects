public class CallByValue {
    public static void main(String[] args) {
        int a=100;
        System.out.println(a);
        int b=a;
        System.out.println(b);
        System.out.println(a);
    }
}
