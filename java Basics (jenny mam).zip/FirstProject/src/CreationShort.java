public class CreationShort {

    public static void main(String[] args) {
        int a=10,b=0,c;
        try{
            System.out.println(a/b);
        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
        System.out.println("sandeep");
    }
}
