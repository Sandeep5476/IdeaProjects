public class Assignment5 {
    public static void main(String[] args) {
        char ch = '\u2764';
        System.out.println( " "+' '+ch+' '+ch+' '+ch+' '+' '+ch+' '+ch+' '+ch+' '+' ');
        System.out.println(" "+ch+' '+' '+' '+' '+' '+' '+ch+' '+' '+' '+' '+' '+' '+ch);
        System.out.println(" "+' '+ch+"\t\t"+' '+' '+' '+ch);
        System.out.println(" "+' '+' '+ch+"\t\t"+' '+' '+ch);
        System.out.println(" "+' '+' '+' '+' '+ch+"\t\t"+ch);
        System.out.println(" "+' '+' '+' '+' '+' '+' '+' '+ch);
    }
}
