public class Intv1 {
    public static void main(String[] args){
//     int a =11,b=12;
//     a=a+b;
//     b=Math.abs(a-b);
//     a=a-b;
//        System.out.println("The value of a is "+a);
//        System.out.println("the value of b is "+b);
    //another program

    int a=10,b=5;
       // System.out.println(a|b);
        System.out.println(a&b);
        //System.out.println(a^b);


    }
}
