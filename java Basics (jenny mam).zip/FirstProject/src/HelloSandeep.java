public class HelloSandeep {
    public static void main(String args[]){
        System.out.println("I am sandeep");
        System.out.println("Java");
        System.out.println("c");
        System.out.println("python");

    }
}
