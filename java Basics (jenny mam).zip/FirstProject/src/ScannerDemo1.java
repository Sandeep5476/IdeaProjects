import java.util.Scanner;

public class ScannerDemo1 {
        public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);

            System.out.println("enter integer value: ");
            int a = sc.nextInt();

            System.out.println("enter String value: ");
            String b = sc.nextLine();




}
    }

