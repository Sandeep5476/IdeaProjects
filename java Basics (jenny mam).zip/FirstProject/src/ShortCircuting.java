public class ShortCircuting {
    public static void main(String[] args) {
        int a=11,b=12;
       if(a<b){
           System.out.println("inside if");
       }
    }
}
