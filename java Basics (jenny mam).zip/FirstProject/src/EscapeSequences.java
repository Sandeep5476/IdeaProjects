public class EscapeSequences {
    public static void main(String[] args) throws InterruptedException{
        System.out.print("Is sandeep good?");
        Thread.sleep(3000);
        System.out.print("\rdefinitely good");

    }
}
