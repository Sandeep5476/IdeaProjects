public class IncrementOperators {
    public static void main(String[] args) {

    int a = 10,b=20;
    int result = a+b - b++ + ++a - a++ * ++b;
        System.out.println(result);
}}
