public class Creation {
    char ch = '\u0c26';
    char ch1 = '\u0c38';
    char ch2 = '\u0c30';
    char ch3 = '\u0c3E';
    char ch4 = ' ';
    char ch5 = '\u0c36';
    char ch6 = '\u0c41';
    char ch7 = '\u0c2D';
    char ch8 = '\u0c3E';
    char ch9 = '\u0c15';
    char ch10 = '\u0c3E';
    char ch11 = '\u0c02';
    char ch12 = '\u0c37';
    char ch13 = '\u0c32';
    char ch14 = '\u0c41';

    void display(){
        System.out.println("made by sandeep  : "+ch+ch1+ch2+ch3+ch4+ch5+ch6+ch7+ch8+ch9+ch10+ch11+ch12+ch13+ch14);
    }

    public static void main(String[] args) {
        Creation obj = new Creation();
        obj.display();
    }
}

