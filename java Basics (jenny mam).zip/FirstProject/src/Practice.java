public class Practice {
    public static void main(String[] args) {
        String x = "sam";
        for (int i = 0; i <= 5; i++) {
            System.out.println(x);
        }


    }}

